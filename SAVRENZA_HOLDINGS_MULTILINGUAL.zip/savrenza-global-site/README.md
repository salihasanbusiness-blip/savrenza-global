# SAVRENZA HOLDINGS — multilingual website

Static website: upload `index.html` and `translations.js` to the same deployment directory. No build step required. Cloudflare Pages: deploy root directory, build command empty.

Languages: English, Arabic, Bulgarian have full reviewed-draft content; German, French, Spanish, Turkish, Chinese, Japanese, Korean, Hindi and Portuguese currently translate navigation and hero only and fall back to English for other content. **Do not describe the site as fully translated into all languages.** Complete and professionally review each locale before launch.

Legal: Dubai formation is planned, not completed. The Arabic legal name is proposed and not registrar-approved. No licensed investment services are offered. Verify company name, trademarks, licensing, contact information, and legal pages before publication.
