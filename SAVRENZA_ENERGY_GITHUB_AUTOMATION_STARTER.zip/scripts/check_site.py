from pathlib import Path
from html.parser import HTMLParser
import sys
root=Path(__file__).resolve().parents[1]
class Links(HTMLParser):
 def __init__(self): super().__init__(); self.refs=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ('script','img','link'):
   v=a.get('src') or a.get('href')
   if v and v.startswith('/') and not v.startswith('//'): self.refs.append(v.split('?')[0].split('#')[0])
issues=[]
for page in root.glob('*.html'):
 p=Links();p.feed(page.read_text(encoding='utf-8'))
 for ref in p.refs:
  if not (root/ref.lstrip('/')).is_file():issues.append(f'{page.name}: missing {ref}')
if not (root/'index.html').exists(): issues.append('Missing index.html')
if issues:
 print('\n'.join(issues));sys.exit(1)
print('PASS: local asset references in root HTML files exist')
