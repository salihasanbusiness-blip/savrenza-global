#!/usr/bin/env python3
"""Check production landing-page invariants without network access."""
from pathlib import Path
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
s=(root/'index.html').read_text()
class Document(HTMLParser):
 def __init__(self): super().__init__();self.ids=set();self.links=[];self.scripts=[]
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if 'id' in d: self.ids.add(d['id'])
  if tag=='a': self.links.append(d.get('href',''))
  if tag=='script': self.scripts.append(d.get('src',''))
d=Document();d.feed(s)
assert len(d.ids)==s.count('id="'), 'Duplicate or malformed ID'
assert 'main-content' in d.ids and '#main-content' in d.links
assert 'primary-nav' in d.ids and 'menu-toggle' in d.ids
assert 'mailto:info@savrenzaplatform.com' in d.links
assert 'https://savrenzaplatform.com/' in s
assert 'assets/holdings-accessibility.js' in d.scripts
assert 'is a developing brand' in s
print('PASS: Holdings landing-page basic structural checks')
