const EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TOPICS=new Set(['Brand & content','Financial technology','Future ventures','Other business enquiry']);
module.exports=async function handler(req,res){
  res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST'){res.setHeader('Allow','POST');return res.status(405).json({error:'Method not allowed.'});}
  const origin=req.headers.origin;
  if(origin){try{const u=new URL(origin);if(u.protocol!=='https:'||!(['savrenzaplatform.com','www.savrenzaplatform.com'].includes(u.hostname)||u.hostname.endsWith('.vercel.app')))return res.status(403).json({error:'Origin not allowed.'});}catch{return res.status(403).json({error:'Invalid origin.'});}}
  const raw=typeof req.body==='string'?req.body:JSON.stringify(req.body||{});
  if(Buffer.byteLength(raw,'utf8')>12000)return res.status(413).json({error:'Message too large.'});
  let body;try{body=typeof req.body==='string'?JSON.parse(req.body):req.body||{}}catch{return res.status(400).json({error:'Invalid request.'});}
  if(body.website)return res.status(200).json({ok:true});
  const name=String(body.name||'').trim(),email=String(body.email||'').trim(),topic=String(body.topic||''),message=String(body.message||'').trim();
  if(!body.consent||name.length<2||name.length>100||email.length>254||!EMAIL_RE.test(email)||!TOPICS.has(topic)||message.length<10||message.length>4000)return res.status(400).json({error:'Please complete all required fields.'});
  const key=process.env.RESEND_API_KEY,from=process.env.CONTACT_FROM_EMAIL,to=process.env.CONTACT_TO_EMAIL||'info@savrenzaplatform.com';
  if(!key||!from)return res.status(503).json({error:'Contact form is not configured yet.'});
  const escape=(v)=>v.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  try{const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({from,to:[to],reply_to:email,subject:'SAVRENZA enquiry: '+topic,html:`<h2>New business enquiry</h2><p><b>Name:</b> ${escape(name)}</p><p><b>Email:</b> ${escape(email)}</p><p><b>Topic:</b> ${escape(topic)}</p><p><b>Message:</b><br>${escape(message).replace(/\n/g,'<br>')}</p>`})});
    if(!response.ok)return res.status(502).json({error:'Delivery is temporarily unavailable.'});
    return res.status(200).json({ok:true});
  }catch{return res.status(502).json({error:'Delivery is temporarily unavailable.'});}
};
