# SAVRENZA — настройка на контактната форма

1. Качи **разархивираните файлове** в GitHub хранилището, което Vercel използва, включително новата папка `api`.
2. В Resend потвърди домейна `savrenzaplatform.com` (DNS записи според Resend).
3. Във Vercel → Project → Settings → Environment Variables добави:
   - `RESEND_API_KEY` — секретният API ключ от Resend (никога в GitHub).
   - `CONTACT_FROM_EMAIL` — потвърден адрес от твоя домейн, например `SAVRENZA <contact@savrenzaplatform.com>`.
   - `CONTACT_TO_EMAIL` — `info@savrenzaplatform.com`.
4. Redeploy след добавяне на променливите.
5. Изпрати тестово запитване и провери реално получаване на имейл.

ВАЖНО: Формата не изпраща нищо, докато Resend не е конфигуриран. За реален публичен трафик добави rate limiting и CAPTCHA/Turnstile. Не качвай ZIP файла като един файл в GitHub; качи съдържанието му. Ако старите файлове останат, изтрий ненужните от основната директория след резервно копие.
