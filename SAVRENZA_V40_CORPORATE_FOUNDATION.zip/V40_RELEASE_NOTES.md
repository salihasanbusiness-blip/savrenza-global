# SAVRENZA V40 — Corporate Foundation

## Changes
- Added a clearly labeled investment philosophy section with four principles.
- Added a Dubai planned-headquarters section, explicitly disclosing that company formation has not occurred.
- Improved keyboard focus and reduced-motion support.
- Updated metadata to describe the brand accurately.
- Excluded legacy release ZIPs from this distribution to avoid publishing historical archives.

## Limitations
- This package is not deployed to GitHub or Cloudflare.
- Existing JavaScript and worker code are retained, not independently security-certified.
- The site does not represent a registered or licensed investment business.
- Validate in browsers, verify legal disclosures and run deployment checks before production release.
