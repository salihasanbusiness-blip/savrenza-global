# SAVRENZA V38 — Modern Global Edition

Built from the prior institutional edition. Design changes only: navy/gold visual system, modern typography, hero, cards, mobile and focus styling. Existing translations and content preserved.

Deploy the contents of this folder to the repository root, not the folder itself. No claim of audited security, regulatory status, or production readiness. Verify links, translations, accessibility and mobile browser behavior before launch.
