# SAVRENZA HOLDINGS V35 — RELEASE CANDIDATE

## Status
Package prepared for GitHub preview testing. NOT deployed, NOT certified 10/10.

## Provenance
Based on the previously prepared V31 preview archive supplied in this conversation. Existing application files, translations, Cloudflare worker, and deployment workflows retained unchanged.

## Critical checks before merging into main
1. Create a branch from the latest main; compare changes before applying.
2. Deploy via Cloudflare Pages preview and verify actual preview URL.
3. Test iPhone/Android menu, keyboard access, translations including Arabic RTL, and all links.
4. Confirm whether SAVRENZA ENERGY is an intentionally separate AI product: `_worker.js` still describes SAVRENZA ENERGY, not HOLDINGS. Do not activate AI without validating business claims and Turnstile settings.
5. Confirm real company registration, location, legal notices, privacy and contact channels.
6. Test actual HTTP security headers, CSP, cache behavior, 404 page and forms.
7. Run Lighthouse mobile and desktop on the deployed preview; no performance score has been measured here.
8. Only merge after preview acceptance and rollback plan.

## Automated static checks
See V35_STATIC_AUDIT.json. These checks cannot prove live functionality.
