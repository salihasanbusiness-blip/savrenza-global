# SAVRENZA V31 — Preview only

Тази версия е изградена върху предоставения ZIP архив. Не е публикувана.

## Реални промени
- Canonical URL, Open Graph и Twitter metadata, favicon и manifest в index.html.
- Видима мобилна навигация (преди беше скрита под 850px).
- Skip-to-content, keyboard focus, минимални 44px мобилни контроли и reduced-motion поддръжка.
- Подобрени адаптивни размери на hero, бутони и cards.
- Запазени translations.js, всички съществуващи файлове, Cloudflare Worker и конфигурацията.

## Преди production
1. Качете в отделен branch и тествайте Cloudflare Pages Preview.
2. Проверете навигацията и преводите, включително арабски RTL.
3. Проверете правните данни и действителния статус на компанията.
4. Пуснете Lighthouse на публикуван preview; оценки 10/10 не са гарантирани.
5. Проверете Cloudflare Worker, CSP и security headers отделно.

## Установен риск
_worker.js съдържа описание на SAVRENZA ENERGY, докато началната страница е SAVRENZA HOLDINGS. Преди активиране на AI функционалност проверете съответствието на брандовете и фактите.
